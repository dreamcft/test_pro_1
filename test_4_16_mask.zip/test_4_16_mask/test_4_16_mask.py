import cv2
import os
import numpy as np
from matplotlib import pyplot as plt
import glob
#255 白
#0   黑

#一些处理参数
pd_erode = 9
pd_dilate = 9
pd_blur_kernel  = 11
pd_blur_kerne2  = 11

#ROI参数
roi_x_start = 150
roi_x_add = 200
roi_y_start = 200
roi_y_add = 200


pic_cls_num = 7
# pic_cls_name = ["open", "hold", "one", "yeah", "okay", "good"]
# label_cls = {"open": 0, "hold": 1, "one": 2, "yeah": 3, "okay": 4, "good": 5}
pic_cls_name = ["left", "right", "up", "down", "stop", "open","none"]
label_cls = {"left": 0, "right": 1, "up": 2, "down": 3, "stop": 4, "open": 5, "none": 6}

set_cls_name = [ "train", "test"]

pic_root_dir = "img/"

#新建文件夹
def mkdir(dir_name):
    dir = os.path.exists(dir_name)
    if not dir:
        print("create dir...")
        os.makedirs(dir_name)
        print("done!")
    else:
        print("the floder named "+dir_name+" alredy exists!")


#获取掩码图
def get_skin_mask(img, in_H_low = 0, in_H_high = 30):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    lower_blue = np.array([in_H_low, 30, 0])
    upper_blue = np.array([in_H_high, 180, 255])

    mask = cv2.inRange(hsv, lower_blue, upper_blue)

    # lower_blue = np.array([150, 30, 0])
    # upper_blue = np.array([170, 180, 255])
    #
    # mask1 = cv2.inRange(hsv, lower_blue, upper_blue)

    mask2 = mask
    return mask2

#获取凸包线
def draw_hull(img):
    contours, hierarchy = cv2.findContours(img.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    for c in contours:
        len = cv2.contourArea(c)
        if len < 1000 or len > 20000:
            continue

        M = cv2.moments(c)  # 计算第一条轮廓的各阶矩,字典形式
        center_x = int(M["m10"] / M["m00"])
        center_y = int(M["m01"] / M["m00"])

        cv2.circle(img, (center_x, center_y), 7, 255, -1)

        hull = cv2.convexHull(c, returnPoints=True)

        cv2.polylines(img, [hull], True, 255, 2)

    return img

#输入图片描述
def insert_str(in_img, in_str="", in_x_y=(0,0), in_font = cv2.FONT_HERSHEY_SIMPLEX, in_size=1.2, in_color=(255,255,255), in_weigth=2 ):
    in_img = cv2.putText(in_img, in_str, in_x_y, in_font, in_size, in_color, in_weigth)
    return in_img

#不做啥的回调函数
def nothing():
    pass
#主程序开始

##新建数据集文件夹

# for new_dir in pic_cls_name:
#     mkdir(pic_root_dir+set_cls_name[0]+"/"+new_dir)


cap = cv2.VideoCapture(0)
i = 1
pic_num = 0
dir_index = 0

save_flag = False
cv2.namedWindow("frame")
cv2.createTrackbar("H_low", "frame", 0, 255, nothing)
cv2.createTrackbar("H_high", "frame", 0, 255, nothing)
cv2.createTrackbar("blur_1", "frame", 1, 255, nothing)
cv2.createTrackbar("blur_2", "frame", 1, 255, nothing)
while True:
    ret,frame = cap.read()



    kernel_erode = cv2.getStructuringElement(cv2.MORPH_RECT, (pd_erode, pd_erode))
    kernel_dilate = cv2.getStructuringElement(cv2.MORPH_RECT, (pd_dilate, pd_dilate))

    dst = frame[ roi_y_start:(roi_y_start+roi_y_add), roi_x_start:(roi_x_start+roi_x_add)]
    gray = cv2.cvtColor(dst, cv2.COLOR_BGR2GRAY)

    dst = cv2.GaussianBlur(dst, (pd_blur_kernel, pd_blur_kernel),0)
    dst = cv2.dilate(dst, kernel_dilate)
    dst = cv2.erode(dst, kernel_erode)
    dst = cv2.GaussianBlur(dst, (pd_blur_kernel, pd_blur_kerne2),0)

    mask = get_skin_mask(dst)
    mask = draw_hull(mask)
    gray = mask & gray
    # gray = cv2.flip(gray, 1)
    cv2.imshow('gray',gray)#另一窗口显示处理视频


    # pd_erode = cv2.getTrackbarPos("erode", "frame")
    # pd_dilate = cv2.getTrackbarPos("dilate", "frame")
    # pd_blur_kernel = cv2.getTrackbarPos("blur_1", "frame")
    # pd_blur_kerne2 = cv2.getTrackbarPos("blur_2", "frame")
    # insert_str(frame,
    #            "erode: "+str(pd_erode)+"  dilate:"+str(pd_dilate)+"  blur_1:"+str(pd_blur_kernel)+"  blur_2:"+str(pd_blur_kerne2),
    #            in_x_y=(10,100),
    #            in_size=0.8,
    #            in_color=(0,0,255),
    #            in_weigth=2
    #            )
    mini_img = cv2.resize(gray, (64, 64), interpolation=cv2.INTER_AREA)
    key = cv2.waitKey(1)
    if  key & 0xFF == ord('q'):
        break
    # elif key & 0xFF == ord('s'):
    #     cv2.imwrite("./img/"+str(i)+'.jpg', mini_img)
    #     i += 1
    # 制作数据集用代码
    elif key & 0xFF == ord('s'):
        save_flag = True
        print("start save : " + pic_cls_name[dir_index])

    if i % 2 == 0 and save_flag:
        print("saving pic...")
        cv2.imwrite("./img/test/"+pic_cls_name[dir_index]+"/" + str(pic_num) + '_3.png', mini_img)
        pic_num += 1
        print("saving done! now pic'num is :" + str(pic_num))
        i = 0

    if pic_num == 100:
        dir_index += 1
        if dir_index == pic_cls_num:
            print("ALL FINISHED!!!")
            i = 0
        else:
            pic_num = 0
            print("next pic'class is :" + pic_cls_name[dir_index]+"and press 'S' to start save pic")
        save_flag = False
    i += 1
    cv2.rectangle(frame,
                  (roi_x_start,roi_y_start),
                  ( roi_x_start+roi_x_add, roi_y_start+roi_y_add),
                  (0, 0, 255),
                  thickness=3)
    cv2.imshow('frame',frame)#一个窗口用以显示原视频


cap.release()


# #数据增强 水平反转图片
# img_dir = "img/test/left/"
# save_dir = "img/test/right/"
# i = 0
# print("start")
# for img in os.listdir(img_dir):
#     img = cv2.imread(img_dir+img)
#     img = cv2.flip(img, 1)
#     cv2.imwrite(save_dir+str(i)+"_filp.png", img)
#     i += 1
#
# print("Done!")
# cv2.destroyAllWindows()